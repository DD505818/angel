
import React from 'react';
import { View, Text } from 'react-native';

export default function Wallet() {
  return (
    <View><Text>Balances, Transfers, Deposits</Text></View>
  );
}
