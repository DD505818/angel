
import React from 'react';
import { View, Text } from 'react-native';

export default function Dashboard() {
  return (
    <View><Text>Real-Time PnL, CVaR, Sharpe, Agent Status</Text></View>
  );
}
