
import React from 'react';
import { View, Text } from 'react-native';

export default function Agents() {
  return (
    <View><Text>Activate / Pause / Kill agents</Text></View>
  );
}
